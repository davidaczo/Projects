export type Species = {
    nameCommon: string;
    nameLatin: string;
  };