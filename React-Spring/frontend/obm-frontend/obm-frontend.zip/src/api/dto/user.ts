export type User = {
    id: number;
    dateOfBirth: string;
    email: string;
    firstName: string;
    lastName: string;
    role: string;
    username: string;
  };