export type Country = {
  countryId: number;
  countryName: string;
  numberOfLocations: number;
};