import React from 'react';
import { CountriesTable } from '../components/table/countries/countries-table';

export const CountriesScreen = () => {
    return (
        <CountriesTable />
    ) 
};