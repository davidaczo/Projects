import React from 'react';
import { LocationTable } from '../components/table/locations/location-table';

export const LocationScreen = () => {
    return (
        <LocationTable />
    ) 
};