import React from 'react';
import { UserTable } from '../components/table/users/users-table';

export const UsersScreen = () => {
    return (
        <UserTable />
    ) 
};