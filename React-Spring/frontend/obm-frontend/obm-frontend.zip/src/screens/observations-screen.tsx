import React from 'react';
import { ObservationsTable } from '../components/table/observations/observations-table';

export const ObservationsScreen = () => {
    return (
        <ObservationsTable />
    ) 
};