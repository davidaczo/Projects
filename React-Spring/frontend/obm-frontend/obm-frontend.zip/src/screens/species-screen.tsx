import React from 'react';
import { SpeciesTable } from '../components/table/species/species-table';

export const SpeciesScreen = () => {
    return (
        <SpeciesTable />
    ) 
};