export type User = {
active: boolean,
dateOfBirth: string,
email: string,
firstName: string,
lastName: string,
role: string,
userId: number
username: string,
}