export const checkSpeciesFilter = (input: string) => input.length >= 3;
