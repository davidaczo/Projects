export type User = {
    id: number,
    role: string,
    firstName: string,
    lastName: string,
    username: string,
    dateOfBirth: string,
    email: string
}