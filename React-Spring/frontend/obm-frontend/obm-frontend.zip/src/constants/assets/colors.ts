export const PLOT_COLOR = '#0000FF';
export const SELECTED_PLOT_COLOR = '#6666ff';
